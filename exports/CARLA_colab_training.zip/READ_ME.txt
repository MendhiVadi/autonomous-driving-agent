Extract this archive into My Drive/CARLA so the JSONL files are in CARLA/episodes.
Open colab_train_policy.ipynb in Google Colab and run its cells.
Use the real-data path, not synthetic smoke-test mode.
The notebook separates complete episodes into train, validation and test sets.
Model optimization happens in Colab; these files are demonstrations, not trained weights.
Evaluate the exported policy on Town04 before using it for a live presentation.
